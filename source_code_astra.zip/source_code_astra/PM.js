const url = './source_code_astra/text.txt';

const response = await fetch(url);            // await is okay here if top-level
let text = await response.text();           // get actual text content
text = text.toLowerCase()


function levenshteinDistance(a, b) {
    let dp = Array(a.length + 1).fill(null).map(() => Array(b.length + 1).fill(0));

    for (let i = 0; i <= a.length; i++) dp[i][0] = i;
    for (let j = 0; j <= b.length; j++) dp[0][j] = j;

    for (let i = 1; i <= a.length; i++) {
        for (let j = 1; j <= b.length; j++) {
            let cost = a[i - 1] === b[j - 1] ? 0 : 1;
            dp[i][j] = Math.min(
                dp[i - 1][j] + 1, 
                dp[i][j - 1] + 1, 
                dp[i - 1][j - 1] + cost 
            );
        }
    }
    return dp[a.length][b.length];
}

// Get Trigrams
function getTrigrams(word) {
    let trigrams = new Set();
    if (word.length < 3) return trigrams; 
    for (let i = 0; i < word.length - 2; i++) {
        trigrams.add(word.slice(i, i + 3));
    }
    return trigrams;
}

// Best Match Finder
function getBestMatch(query, dataset) {
    let bestMatch = query;
    let highestScore = -1;

    let queryTrigrams = getTrigrams(query);

    for (let word of dataset) {
        let wordTrigrams = getTrigrams(word);
        let commonTrigrams = [...queryTrigrams].filter(tri => wordTrigrams.has(tri)).length;

        let trigramScore = (query.length > 2 && word.length > 2) ? 
            (commonTrigrams / Math.max(queryTrigrams.size, wordTrigrams.size)) : 0;

        let levenshteinScore = 1 - (levenshteinDistance(query, word) / Math.max(query.length, word.length));

        let finalScore = (trigramScore * 0.5) + (levenshteinScore * 0.5);


        if (finalScore > highestScore) {
            highestScore = finalScore;
            bestMatch = word;
        }
    }


    return highestScore > 0.4 ? bestMatch : query;
}

function correctSentence(sentence, dataset) {
    let words = sentence.split(" ");
    let correctedWords = words.map(word => getBestMatch(word, dataset));
    return correctedWords.join(" ");
}

class Sentence_Formator {
    constructor(query) {
        this.query = query
    }
    clean() {
        let query_words = this.query.trim().split(" ")
        let stopwords_array = ['what', 'is', 'am', 'are', '?', '.', '!', 'who', 'where', 'a', 'an', 'the', 'aree', 'bhai', 'kya', 'hote', 'hai']
        for (let i = 0; i <= stopwords_array.length - 1; i++) {
            for (let j = 0; j <= query_words.length - 1; j++) {
                if (query_words[j] == stopwords_array[i]) {
                    query_words.splice(j, 1)
                }
            }
        }
        return query_words.join(" ").replaceAll("?", '').replaceAll(".", '').replaceAll("!", '').replaceAll("hai", '').trim()
    }
    remove_punctuation_like_QSmark_and_EXCMark() {
        let query_words = this.query.trim().split("")
        let stopwords_array = ['?', '!', ',']
        for (let i = 0; i <= stopwords_array.length - 1; i++) {
            for (let j = 0; j <= query_words.length - 1; j++) {
                if (query_words[j] == stopwords_array[i]) {
                    query_words.splice(j, 1)
                }
            }
        }
        return query_words.join("").trim()
    }
}

let formattor = new Sentence_Formator(text)
text = formattor.remove_punctuation_like_QSmark_and_EXCMark()


let words = text.split(/\s+/);

let parameters = [
    ['hello', ['howdy'], 'greeting']
]

// Create the frequency map for n-grams (unigrams, bigrams, trigrams, quadrigrams)
function buildFrequencyMap(text) {
    const frequencyMap = {
        unigram: {},
        bigram: {},
        trigram: {},
        quadrigram: {}
    };
    const wordsArray = text.split(/\s+/);

    for (let i = 0; i < wordsArray.length - 1; i++) {
        const unigram = wordsArray[i].toLowerCase();
        const bigram = (wordsArray[i] + " " + wordsArray[i + 1]).toLowerCase();
        const trigram = (wordsArray[i] + " " + wordsArray[i + 1] + " " + wordsArray[i + 2] || "").toLowerCase();
        const quadrigram = (wordsArray[i] + " " + wordsArray[i + 1] + " " + wordsArray[i + 2] + " " + wordsArray[i + 3] || "").toLowerCase();
        const nextWord = wordsArray[i + 1] ?.toLowerCase();

        // Unigram map
        if (!frequencyMap.unigram[unigram]) frequencyMap.unigram[unigram] = {};
        frequencyMap.unigram[unigram][nextWord] = (frequencyMap.unigram[unigram][nextWord] || 0) + 1;

        // Bigram map
        if (i < wordsArray.length - 2) {
            if (!frequencyMap.bigram[bigram]) frequencyMap.bigram[bigram] = {};
            frequencyMap.bigram[bigram][wordsArray[i + 2] ?.toLowerCase()] = (frequencyMap.bigram[bigram][wordsArray[i + 2] ?.toLowerCase()] || 0) + 1;
        }

        // Trigram map
        if (i < wordsArray.length - 3) {
            if (!frequencyMap.trigram[trigram]) frequencyMap.trigram[trigram] = {};
            frequencyMap.trigram[trigram][wordsArray[i + 3] ?.toLowerCase()] = (frequencyMap.trigram[trigram][wordsArray[i + 3] ?.toLowerCase()] || 0) + 1;
        }

        // Quadrigram map
        if (i < wordsArray.length - 4) {
            if (!frequencyMap.quadrigram[quadrigram]) frequencyMap.quadrigram[quadrigram] = {};
            frequencyMap.quadrigram[quadrigram][wordsArray[i + 4] ?.toLowerCase()] = (frequencyMap.quadrigram[quadrigram][wordsArray[i + 4] ?.toLowerCase()] || 0) + 1;
        }
    }

    return frequencyMap;
}

// Choosing the best next word based on frequency
function getBestNextWord(seed, map) {
    if (!map[seed]) return null;

    const nextWords = map[seed];
    let bestWord = null;
    let maxFrequency = 0;

    for (const [nextWord, frequency] of Object.entries(nextWords)) {
        if (frequency > maxFrequency) {
            bestWord = nextWord;
            maxFrequency = frequency;
        }
    }

    return bestWord;
}

// Generate the next word, fallback to random if no match
function generate_next_word(query, frequencyMap, maxDepth = 10000000, depth = 0) {
    let letter = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
    let Lang = ""
    for (let i = 0; i <= letter.length - 1; i++) {
        if (query.includes(letter[i])) {
            Lang = "eng"
        } else {
            Lang = "hin"
        }
    }
    if (depth > maxDepth) {
        console.log("Max recursion depth reached. Returning query.");
        return query;
    }

    let sentiment

    for (let i = 0; i <= parameters.length - 1; i++) {
        if (query.includes(parameters[i][0])) {
            query = parameters[i][1][Math.floor(Math.random() * parameters[i][1].length)]
            console.log(query)
            console.log('yes/////////')
            if (parameters[i][2] == 'greeting') {
                console.log('yes')
                sentiment = 'greeting'
            }
        }
    }

    let hasEmoji = (query) => {
        let emojis = '😀😁😂🤣😃😄😅😆😉😊😋😎😍😘🥰😗😙😚☺🙂🤗🤩🤔🤨😐😑😶🙄😏😣😥😮🤐😯😪😫🥱😴😌😛😜😝🤤😒😓😔😕🙃🤑😲☹🙁😖😞😟😤😢😭😦😧😨😩🤯😬😰😱🥵🥶😳🤪😵🥴😠😡🤬😷🤒🤕🤢🤮🤧😇🥳🥺🤠🤡🤥🤫🤭🧐🤓😈👿👹👺💀☠👻👽👾🤖💩😸😺🐱‍🏍🐱‍💻🐱‍🐉🐱‍👓🐱‍🚀🙈🙉🙊🐵🐶🐺🐱🦁🐯🦒🦊🌊💧🔥❄⚡⛱☔☂🌈⛄🌀🌬🌡☄🌠🌙🌚🌛🌜☀🌞⭐🌟🌝🌫🌪🌩🌧🌥'
        let emoji_array = emojis.split('')
        for (let i = 0; i <= emoji_array.length - 1; i++) {
            if (query.includes(emoji_array[i])) {
                console.log("bhai sahab ismen toh emoji hai")
                return true
            } else {
                return false
            }
        }
    }



    if (query.split(".").length > 3 || hasEmoji(query) || query.split("?").length == 2 && Lang == "eng" && sentiment !== 'greeting') {
        return query
    }

    if (sentiment == 'greeting' && query.split(".").length == 2) {
        return query
    }

    if (query.split("।").length > 3 || hasEmoji(query) || query.split("?").length == 4 || query.split("!").length == 2 && Lang == "hin") {
        console.log(query.split("?"))
        return query
    }

    let queryWords = query.split(" ");

    const seeds = [
        queryWords.slice(-4).join(" ").toLowerCase(),
        queryWords.slice(-3).join(" ").toLowerCase(),
        queryWords.slice(-2).join(" ").toLowerCase(),
        queryWords.slice(-1).join(" ").toLowerCase()
    ];

    let nextWord = null;

    // Try each n-gram seed
    for (let i = 0; i < seeds.length; i++) {
        const seed = seeds[i];
        const map = frequencyMap[["quadrigram", "trigram", "bigram", "unigram"][i]];
        nextWord = getBestNextWord(seed, map);
        if (nextWord) break;
    }

    // If no word found, generate a random word from the entire text as fallback
    if (!nextWord) {
        return null
    }

    // If no suitable word or word repetition is detected, stop the generation
    if (!nextWord) {
        console.log("No next word found or word repetition detected.");
        return query;
    }

    // Add the word and recurse
    query += " " + nextWord;
    return generate_next_word(query, frequencyMap, maxDepth, depth + 1);
}

console.log("Training Data Length:- "+text.length)

function return_response(query) {
    query = correctSentence(query,text.split(' '))
    let cleaner = new Sentence_Formator(query)
    const frequencyMap = buildFrequencyMap(text);
    const generatedSentence = generate_next_word(cleaner.clean(), frequencyMap);
    console.log("Corrected query: ",query)
    return generatedSentence
}


export { return_response, text }