// THIS IS A CODE SNIPPET MEANT FOR TESTING PURPOSE ONLY

import AstraAI from './index.js';
import readline from 'readline'

let attitude = {
    bot_name: "astra",
    purpose: "personal",
    tasks: "Hobbies, interests or just chat for fun"
};

let astra = new AstraAI(attitude);

let rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});
  
function ask() {
    console.log("\n")
    rl.question('////////////////////////// Ask Vasuki Anything:- ', ques => {
    astra.chat(ques,attitude)
        .then((response) => {
            console.log(response.split(".")[0]);
            ask()
        })
        .catch((error) => {
            console.error("Error:", error);
        });
    });
}

ask()

