import component from "./predefined.js";
import randomFormat from "./format.js";
import { return_response, text } from "./PM.js";

let greeting = ["hello", "hey", "hi", "yo", "howdy"];
let botGreetings = ["hello", "hey", "hi", "hii", "howdy"];

const url = 'https://en.wikipedia.org/api/rest_v1/page/summary/';

let indents = [
    { query: ['hi', 'hello', 'howdy', 'hey', 'yo', 'bhai', 'bro', 'greetings', 'sup', 'what’s up', 'namaste', 'hola', 'bonjour', 'ciao', 'konichiwa', 'salaam', 'shalom'], indent: 'greeting' },
    { query: ['yes', 'yeah', 'yup', 'sure', 'okay', 'ok', 'affirmative', 'correct', 'right'], indent: 'affirmation' },
    { query: ['no', 'nah', 'nope', 'negative', 'never', 'wrong'], indent: 'negation' },
    { query: ['thank you', 'thanks', 'thx', 'appreciate', 'much obliged', 'gracias', 'merci', 'danke'], indent: 'gratitude' },
    { query: ['bye', 'goodbye', 'see ya', 'later', 'farewell', 'adios', 'ciao', 'sayonara'], indent: 'farewell' },
    { query: ['help', 'assist', 'support', 'aid', 'guide', 'how to', 'tutorial', 'explain'], indent: 'assistance' },
    { query: ['weather', 'temperature', 'forecast', 'climate', 'rain', 'sunny', 'storm', 'humidity'], indent: 'weather' },
    { query: ['math', 'algebra', 'geometry', 'calculus', 'equation', 'integral', 'derivative', 'pi', 'probability'], indent: 'mathematics' },
    { query: ['computer', 'CPU', 'RAM', 'GPU', 'SSD', 'motherboard', 'processor', 'hardware', 'software'], indent: 'technology' },
    { query: ['space', 'NASA', 'Mars', 'galaxy', 'black hole', 'star', 'planet', 'orbit', 'astronomy', 'exoplanet', 'cosmos'], indent: 'space' },
    { query:['solve', 'evaluate', 'calculate', 'find', 'compute', 'math'], indent: 'math' },
    { query: ['weather','mausam','barish','garmi','sardi','dhoondh'], indent: 'weather' }
  ];
  

// Conversation history for context
let conversationHistory = [];

let sampleText = `elon reeve musk albert einstein sir issac newton Artificial intelligence is transforming the way we interact with technology. From smart assistants to autonomous vehicles, AI is reshaping industries and daily life.
Machine learning, a subset of AI, enables systems to learn and improve from experience without being explicitly programmed. Algorithms analyze vast datasets to detect patterns, make decisions, and predict outcomes with remarkable accuracy.
Deep learning, which uses artificial neural networks, has pushed the boundaries of what's possible in speech recognition, computer vision, and natural language processing.
Data is the new oil. It fuels the machine learning models and allows businesses to unlock insights, optimize operations, and enhance customer experiences.
In software development, automation powered by AI is reducing human effort in testing, bug detection, and even code generation. Developers now rely on tools like GitHub Copilot to suggest code snippets and accelerate development.
Natural language processing has evolved significantly. Chatbots today can understand context, detect intent, and generate human-like responses, making customer support more efficient and accessible.
Big data analytics is another domain benefiting from AI. By processing terabytes of structured and unstructured data, businesses are making data-driven decisions that lead to better outcomes.
Cybersecurity is being strengthened by AI systems that can detect anomalies, prevent fraud, and adapt to new threats in real-time.
AI in healthcare is enabling faster diagnosis, personalized treatment plans, and drug discovery. Machine learning models are being trained on medical records, images, and genomic data to assist doctors and researchers.
Education is evolving too. Personalized learning platforms use AI to adapt content to individual student needs, track progress, and provide real-time feedback.
Ethical concerns around AI are growing. Issues like algorithmic bias, job displacement, and data privacy must be addressed as the technology continues to advance.
Quantum computing holds the promise of revolutionizing AI by handling complex computations exponentially faster than traditional systems.
Computer vision allows machines to interpret visual data, enabling facial recognition, self-driving cars, and real-time surveillance.
Reinforcement learning trains agents to make decisions by rewarding good actions and penalizing bad ones, mimicking how humans learn from experience.
Augmented reality and AI are merging to create immersive experiences in gaming, education, and retail, allowing users to interact with digital content in the physical world.
The Internet of Things connects devices and sensors to collect real-time data, which AI systems then analyze to optimize performance and predict maintenance needs.
Cloud computing makes powerful AI accessible to developers worldwide by offering scalable resources and services without upfront hardware investment.
Edge AI processes data locally on devices, reducing latency and enhancing privacy, especially in applications like smart cameras and wearable tech.
Startups and tech giants alike are racing to develop general AI — machines that can perform any intellectual task that a human can do.
Researchers are exploring neuromorphic computing, inspired by the human brain, to create more efficient and adaptable AI systems.
Programming languages like Python have become the go-to for AI development due to their rich ecosystems and simplicity.
AI models like GPT, BERT, and DALL·E are revolutionizing language understanding and content generation, from writing essays to creating artwork.
Open-source communities are driving AI innovation by sharing tools, models, and datasets, accelerating progress in the field.
AI ethics emphasizes transparency, accountability, and inclusivity to ensure that AI benefits all of humanity.
AI is not just a tool — it's becoming a collaborator in creative, scientific, and decision-making processes.
As AI becomes more integrated into society, interdisciplinary collaboration among technologists, ethicists, policymakers, and educators is crucial.
Continuous learning, lifelong curiosity, and critical thinking will be essential skills in an AI-augmented future.
The future belongs to those who understand both the capabilities and the limitations of artificial intelligence.
Innovation thrives where bold ideas meet practical application, and AI is the bridge connecting vision to reality. hitler hey hello howdy yo
Physics is the foundation of all natural sciences. It explores the fundamental laws of nature, from the smallest particles to the entire universe.
Classical mechanics, first developed by Newton, explains how objects move under the influence of forces. Laws of motion and gravitation govern the motion of objects on Earth and in space.
Quantum mechanics revolutionized our understanding of the microscopic world. It describes the behavior of particles on an atomic and subatomic level, where particles can exist in multiple states at once, defying classical logic.
The theory of relativity, proposed by Albert Einstein, altered our understanding of space, time, and gravity. According to relativity, time and space are not absolute; they are relative and depend on the observer's motion.
Electromagnetism is one of the four fundamental forces of nature. It governs the behavior of charged particles and is responsible for the operation of electric circuits, magnetism, and light.
The strong nuclear force holds the nucleus of an atom together, while the weak nuclear force is responsible for radioactive decay. These forces operate at the subatomic level and are key to understanding atomic structure.
Thermodynamics is the study of energy, heat, and temperature. It describes how energy is transferred between systems and how it affects the behavior of matter. The laws of thermodynamics govern everything from steam engines to black holes.
Fluid mechanics studies the behavior of liquids and gases in motion. It explains how fluids interact with objects and the forces they exert on them, playing a crucial role in aerodynamics and hydrodynamics.
Optics is the study of light and its interactions with matter. It explains phenomena like reflection, refraction, and diffraction, which are essential for understanding how lenses, mirrors, and other optical devices work.
Acoustics focuses on the study of sound and its transmission through different mediums. It plays a critical role in everything from music to medical imaging techniques like ultrasound.
Nuclear physics explores the behavior of atomic nuclei. It has applications in energy generation, nuclear medicine, and understanding the forces that govern the universe.
Cosmology delves into the origins and structure of the universe. It studies galaxies, stars, planets, black holes, and the Big Bang, which are the foundations of our understanding of the cosmos.
Particle physics investigates the fundamental particles that make up all matter and the forces that govern their interactions. The discovery of the Higgs boson at CERN was a monumental step in our understanding of the universe's building blocks.
The theory of chaos explores systems that appear random but are governed by underlying patterns. It has applications in weather prediction, economics, and biology.
Relativity and quantum mechanics are the pillars of modern physics, but unifying these two theories into a single framework — quantum gravity — is one of the biggest challenges in theoretical physics today.
Physics is not only about understanding the natural world but also about applying that knowledge to technology. Innovations like semiconductors, lasers, and MRI machines are all products of physics research.
The future of physics lies in exploring new frontiers like dark matter, dark energy, and the nature of time itself. As our understanding of the universe deepens, we continue to push the boundaries of knowledge and technology.
bhai i always miss you love you too yaar bhai you're my real bro.`+text.toLowerCase().replace(/[.,!?]/g, "").split(/\s+/);

// STEP 1: Bigram Map Banana
let words = sampleText;
let bigramMap = {};

for (let i = 0; i < words.length - 2; i++) {
let key = `${words[i]} ${words[i + 1]}`;
let next = words[i + 2];
if (!bigramMap[key]) bigramMap[key] = {};
bigramMap[key][next] = (bigramMap[key][next] || 0) + 1;
}

// STEP 2: Random Word Picker (with weighted randomness)
function pickNextWord(key) {
let options = bigramMap[key];
if (!options) return null;
let total = Object.values(options).reduce((a, b) => a + b, 0);
let rand = Math.random() * total;
let sum = 0;
for (let word in options) {
    sum += options[word];
    if (rand <= sum) return word;
}
}

// STEP 3: Generation
function generateText(start = "machine learning", maxWords = 40) {
let result = start.split(" ");
for (let i = 0; i < maxWords; i++) {
    let key = `${result[result.length - 2]} ${result[result.length - 1]}`;
    let nextWord = pickNextWord(key);
    if (!nextWord) break;
    result.push(nextWord);

    // Early stopping if sentence seems done
    if ([".", "!", "?"].some(punct => nextWord.endsWith(punct))) break;
}
return result.join(" ");
}

// Levenshtein Distance Function
function levenshteinDistance(a, b) {
    let dp = Array(a.length + 1).fill(null).map(() => Array(b.length + 1).fill(0));

    for (let i = 0; i <= a.length; i++) dp[i][0] = i;
    for (let j = 0; j <= b.length; j++) dp[0][j] = j;

    for (let i = 1; i <= a.length; i++) {
        for (let j = 1; j <= b.length; j++) {
            let cost = a[i - 1] === b[j - 1] ? 0 : 1;
            dp[i][j] = Math.min(
                dp[i - 1][j] + 1, // Deletion
                dp[i][j - 1] + 1, // Insertion
                dp[i - 1][j - 1] + cost // Substitution
            );
        }
    }
    return dp[a.length][b.length];
}

// Get Trigrams
function getTrigrams(word) {
    let trigrams = new Set();
    if (word.length < 3) return trigrams; // Ignore small words
    for (let i = 0; i < word.length - 2; i++) {
        trigrams.add(word.slice(i, i + 3));
    }
    return trigrams;
}

// Best Match Finder
function getBestMatch(query, dataset) {
    let bestMatch = query;
    let highestScore = -1;

    let queryTrigrams = getTrigrams(query);

    for (let word of dataset) {
        let wordTrigrams = getTrigrams(word);
        let commonTrigrams = [...queryTrigrams].filter(tri => wordTrigrams.has(tri)).length;

        let trigramScore = (query.length > 2 && word.length > 2) ? 
            (commonTrigrams / Math.max(queryTrigrams.size, wordTrigrams.size)) : 0;

        let levenshteinScore = 1 - (levenshteinDistance(query, word) / Math.max(query.length, word.length));

        let finalScore = (trigramScore * 0.5) + (levenshteinScore * 0.5);

        // Instead of returning immediately, we check if it's the best match
        if (finalScore > highestScore) {
            highestScore = finalScore;
            bestMatch = word;
        }
    }

    // Return only if the highest score is significant
    return highestScore > 0.4 ? bestMatch : query;
}

// Random Selection Helper
function randomBata(kiska) {
    return kiska[Math.floor(Math.random() * kiska.length)];
}

// Sentence Correction (Fixes All Words with Highest Match)
function correctSentence(sentence, dataset) {
    let words = sentence.split(" ");
    let correctedWords = words.map(word => getBestMatch(word, dataset));
    return correctedWords.join(" ");
}


// Top-k Sampling Function for NLG
function topKSampling(probabilities, k) {
    // Sort probabilities and pick top-k
    let sorted = probabilities
        .map((prob, index) => ({ prob, index }))
        .sort((a, b) => b.prob - a.prob)
        .slice(0, k);

    // Normalize probabilities
    let totalProb = sorted.reduce((sum, item) => sum + item.prob, 0);
    sorted = sorted.map(item => ({ ...item, prob: item.prob / totalProb }));

    // Pick a random index based on probabilities
    let random = Math.random();
    let cumulative = 0;
    for (let item of sorted) {
        cumulative += item.prob;
        if (random < cumulative) {
            return item.index;
        }
    }
    return sorted[0].index; // Fallback to the highest probability
}

// Example Dataset & Query
let dataset = text.split(" ")

// Function to check if a query contains a mathematical expression
function isMathQuery(query) {
    const mathKeywords = ['solve', 'evaluate', 'calculate', 'find', 'math'];
    const mathExpressionRegex = /[-+*/^()0-9\s.=]/; // Regex to detect math expressions
    return mathKeywords.some(keyword => query.includes(keyword)) ? query.split(" ")[0].toLowerCase() == "solve" : false && mathExpressionRegex.test(query)
}

// Function to extract and solve mathematical expressions
function solveMathExpression(query) {
    try {
        // Extract the mathematical expression from the query
        const mathExpression = query.replace(/solve|evaluate|calculate|find/gi, "").trim();
        const sanitizedExpression = mathExpression.replace(/[^0-9+\-*/().\s]/g, "").trim(); // Remove invalid characters

        if (!sanitizedExpression) {
            return "I couldn't find a valid mathematical expression in your query.";
        }

        const result = eval(sanitizedExpression); // Evaluate the expression

        // Ensure randomFormat is a function or handle it as a string
        let format = typeof randomFormat === "function" ? randomFormat("math") : "The result is {answer}.";
        format = format.replaceAll("{answer}", result);

        return format; // Return the formatted result
    } catch (error) {
        console.error("Error evaluating math expression:", error);
        return "I couldn't evaluate the mathematical expression. Please check the syntax.";
    }
}

async function fetchAnswer(query, attitude) {
    // Add the user's query to the conversation history
    conversationHistory.push({ user: query });
    // Check if the query is a mathematical query
    if (isMathQuery(query)) {
        return solveMathExpression(query);
    }

    query = query.replaceAll('about', '').replace(/\s+/g, ' ').trim();
    const words = query.split(' ');

    // Combine conversation history into a single context

    console.log("autocorrected user query:", correctSentence(query, dataset));
    var indent;
    var predefinedAnswer;

    for (const item of component.predefined) {
    for (const key of item.keyword) {
        if (query.toLowerCase().includes(key.toLowerCase())) {
        return item.answer; // ✅ Works: exits fetchAnswer properly!
        }
    }
    }

            if (query.includes("summarize") || query.includes("make smaller")) {
        let data;

        if (query.includes("-")) {
            data = query.split("-")[1].trim();
        } else if ((query.match(/:/g) || []).length > 0) {
            data = query.split(":")[1].trim();
        } else {
            data = query; // fallback: use entire query if no separator
        }

        if (!data || data.trim().length === 0) {
            return "I couldn't find any text to summarize.";
        }

        function summarize(text, maxSentences = 3) {
            const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
            if (sentences.length <= maxSentences) return text;

            const wordFreq = {};
            const words = text.toLowerCase().replace(/[^a-z\s]/g, "").split(/\s+/);
            words.forEach(word => {
            if (word.length > 3) {
                wordFreq[word] = (wordFreq[word] || 0) + 1;
            }
            });

            const scoredSentences = sentences.map(sentence => {
            const sentenceWords = sentence.toLowerCase().split(/\s+/);
            const score = sentenceWords.reduce((sum, word) => sum + (wordFreq[word] || 0), 0);
            return { sentence, score };
            });

            const topSentences = scoredSentences
            .sort((a, b) => b.score - a.score)
            .slice(0, maxSentences)
            .map(obj => obj.sentence.trim());

            return topSentences.join(" ");
        }

        // Calculate 30% of total sentences, at least 1
        const totalSentences = data.match(/[^.!?]+[.!?]+/g) || [];
        const maxSent = Math.max(1, Math.ceil(totalSentences.length * 0.3));

        const summary = summarize(data, maxSent);

        console.log("Real length:", data.length);
        console.log("Summarized length:", summary.length);

        return "Sure! Here's a summary:\n" + summary;
        }

    if(query.includes("date")){
        const alexer = new Date()
        const date = alexer.getDate()+"/"+(alexer.getMonth()+1)+"/"+alexer.getFullYear()
        return "The date today is as "+date+"."
    }

    if(query.includes("time")){
        const alexer = new Date()
        const time = alexer.getHours()+":"+alexer.getMinutes()
        return "The time right now is "+time+"."
    }

    if(query.includes("expand") || query.includes("make bigger")){
        return "sure! here is a updated version: "+generateText(correctSentence(query,dataset).replace("expand",'').replace("make bigger",''), 100).trim()
    }

    if(query.includes("search")) {
        try {
            const ask = url+query.split("search")[1].trim().replaceAll(" ", "_")
            let summaryUrl = ask;
            let summaryResponse = await fetch(summaryUrl);
            let summaryData = await summaryResponse.json();

            if (summaryData?.extract) {
                conversationHistory[conversationHistory.length - 1].bot = summaryData.extract;
                return summaryData.extract;
            }
        } catch(err) {
            console.log(err)
        }
    }

        if (query.includes("post code") || query.includes("zip code")) {
        let url = 'https://api.zippopotam.us/in/';
        let postalCode = query.match(/\d+/g)?.join('');
        if (postalCode) {
            let get = await fetch(url + postalCode);
            let res = await get.json(); // <-- await here!
            return "I found a place called "+res.places[0]["place name"]+" in "+res.places[0]["state"]+" of "+res["country"]; // correct path
        } else {
            console.log("No postal code found in query.");
        }
        }


    if (query.includes('generate image')) {
        query = query.split("generate image")[1];
        if (!query) throw new Error('Query is required');
        query = query.trim();

        const ACCESS_KEY = 'Kk89El_Xr_ls4BCDCk2Bvz02Z05zHpJHmFPV8To-Y8M';
        const url = `https://api.unsplash.com/search/photos?query=${encodeURIComponent(query)}&per_page=20&client_id=${ACCESS_KEY}`;
        
        const res = await fetch(url);
        if (!res.ok) throw new Error(`API error: ${res.status}`);

        const data = await res.json();
        if (!data.results || data.results.length === 0) throw new Error('No images found for query');
        console.log(data)

        return `<img src="${data.results[0].urls.full.replaceAll(',','.')}" width="100px" alt="${query}" class="generated">`;
    }

    if (query.includes("news")) {
    let apikey = 'pub_74ba4ede482e4651a1423382bbb9600d';

    let geoResponse = await fetch('https://ipapi.co/json/');
    let geoData = await geoResponse.json();
    let country = geoData.country_name || 'world';

    let url = `https://newsdata.io/api/1/latest?apikey=${apikey}&q=${encodeURIComponent(country)}`;
    let news = await fetch(url);
    let response = await news.json();

    if (response.status === 'success' && response.results && response.results.length > 0) {
        let articles = response.results.slice(0, 5); // Get top 5 articles
        let newsResponse = `Here are the latest news articles for ${country}:\n`;
        articles.forEach((article, index) => {
        newsResponse += `${index + 1}. ${article.title}\n   Source: ${article.source_id}\n   Link: <a href="${article.link}" style="color: aliceblue;">${article.link}</a>\n`;
        });

        conversationHistory[conversationHistory.length - 1].bot = newsResponse;

        return newsResponse.replaceAll(".", "");
    } else {
        return `Sorry, I couldn't find news for ${country}.`;
    }
    }


    // WEATHER SPECIFIC HANDLING
    if (indent === 'weather') {
        try {
            // Extract city name from query
            const cityMatch = query.match(/weather of (.+)/i) || query.match(/weather in (.+)/i) || query.match(/(.+) ka mausam/i);
            const city = cityMatch ? cityMatch[1].trim() : query.replace('weather', '').trim();
            
            if (!city) {
                return "Please specify a city name, like 'weather in London' or 'tell weather of Paris'";
            }

            // Step 1: Get coordinates from city name
            const geoResponse = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(city)}`);
            const geoData = await geoResponse.json();
            
            if (!geoData || geoData.length === 0) {
                return `Sorry, I couldn't find weather information for ${city}. Please check the city name and try again.`;
            }

            // Use the first result (most relevant)
            const latitude = geoData[0].lat;
            const longitude = geoData[0].lon;
            const displayName = geoData[0].display_name.split(',')[0];

            // Step 2: Get weather data
            const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true&temperature_unit=celsius&windspeed_unit=kmh&timezone=auto`;
            const weatherResponse = await fetch(weatherUrl);
            const weatherData = await weatherResponse.json();

            if (!weatherData.current_weather) {
                return "Sorry, I couldn't fetch weather data at the moment. Please try again later.";
            }

            const current = weatherData.current_weather;
            const weatherDesc = getWeatherDescription(current.weathercode);
            
            // Format the weather response
            const weatherResponseText = `Current weather in ${displayName}:\n● Temperature: ${current.temperature}°C\n● Wind: ${current.windspeed} km/h\n● Conditions: ${weatherDesc}`;

            conversationHistory[conversationHistory.length - 1].bot = weatherResponseText;
            return weatherResponseText;

        } catch (error) {
            console.error("Weather fetch error:", error);
            return "Sorry, I encountered an error while fetching weather information. Please try again later.";
        }
    }

    
    return return_response(query)
    }
   


// Helper function to convert weather codes to descriptions
function getWeatherDescription(code) {
    const weatherCodes = {
        0: 'Clear sky',
        1: 'Mainly clear',
        2: 'Partly cloudy',
        3: 'Overcast',
        45: 'Fog',
        48: 'Depositing rime fog',
        51: 'Light drizzle',
        53: 'Moderate drizzle',
        55: 'Dense drizzle',
        56: 'Light freezing drizzle',
        57: 'Dense freezing drizzle',
        61: 'Slight rain',
        63: 'Moderate rain',
        65: 'Heavy rain',
        66: 'Light freezing rain',
        67: 'Heavy freezing rain',
        71: 'Slight snow fall',
        73: 'Moderate snow fall',
        75: 'Heavy snow fall',
        77: 'Snow grains',
        80: 'Slight rain showers',
        81: 'Moderate rain showers',
        82: 'Violent rain showers',
        85: 'Slight snow showers',
        86: 'Heavy snow showers',
        95: 'Thunderstorm',
        96: 'Thunderstorm with slight hail',
        99: 'Thunderstorm with heavy hail'
    };
    return weatherCodes[code] || 'Unknown weather conditions';
}


async function AstraAI_run(ques,attitude) {
    try {
        let answer = await fetchAnswer(ques,attitude);
        return answer;  // This is already a string
    } catch (error) {
        console.error("Error getting AI response:", error);
        return "Error fetching response";  
    }
}


// Correct way to get AI response as a string
async function getAstraResponse(ques,attitude) {
    let astra_answer = await AstraAI_run(ques,attitude);
    return astra_answer; // Correctly returns a string
}



console.log("%cThis Model Uses %cAstra.AI %cFor AI Generated Context. You can also use %cAstra.AI %cFor Your Own AI Generated Context.", 
    "color: white;", 
    "color: aqua;", 
    "color: white;",
    "color: #9ae4b3;",
    "color: white;");



class AstraAI {
    constructor(attitude) {
        this.chatID = Math.floor(Math.random() * 999999999999999);
        this.attitude = this.attitude
    }
    getChatID() {
        return this.chatID;
    }
    chat(ques, attitude) {
        return getAstraResponse(ques, attitude)
    }
}

export default AstraAI;