
# Astra.AI - Redifining Intelligence And Flexiblity

## Astra's Philosophy -
Me, as a JS developer was extremely attracted by AI in the development of websites, and Content Creation. I even tried to get into several API's for providing my clients better reach to their audience with AI. I spent nights in exploring all the present 
day AI models, All I saw was either complex syntax or API pricings with **Limitations**.
 That day, i decided to make my own AI so that no other developer suffer to give clients the best the way I did.
 presenting the legend **Astra.AI**, an easy to use conversational AI model made in vanilla JavaScript, So we - The Developers can ensure both flexiblity and speed **with no API limitations or spending our hard-earned money**.

### Welcome To The Diverse World Of Astra AI
I Warmly Thank You For Choosing **ASTRA.AI** as your genAI partner. I am always happy to assist you and look forward for your feedback!
I have some terms & conditions for you for freely access our model Astra-AI. please go through them as follows:-

- Mention @adamya-khairwal or @astra-ai whereever you use this AI model
- Any editing, updation, deletion or insertion in the model's core modules is a punishable offense.
- spread of any rumour or negative value by the consumer will be a punishable task.

we hope these terms find you well.

Astra isn't completely ready and keeps improving itself for your better results. please look forward for new versions of Astra so you
don't miss any important feature. This module was completely made in VANILLA JAVASCRIPT and perhaps, the first ever genAI to be made with JS. 
we would love getting your suggestions at our registered eMail ID: codeclutch.adamyarao@gmail.com or anuradhamaheshwari48@gmail.com.

## to test the model, follow the steps:-

1. **setting environment :-** run npm i -g @adamya_khairwal/astra-cli to install the package
2. **Getting Started :-** After Installing, run:- astra-dir [your_project_name] ==> This will create a directory with inbuilt NodeJS file to run
3. **See The Magic:-** cd to your directory and run node index. See Astra.AI in action !

## Updating The Model
**Here is how you can change model's behaviour or other personality options**
1. You can change bot's name and tasks by updating attitude object.
2. to test this, change the query to "introduce yourself"

## Running without CLI
To run Astra without CLI, follow these steps:-

**Install Astra.AI through NPM**
```bash
npm install astra-ai
```
**Running Code In NodeJS / VanillaJS Environment**
```javascript
import AstraAI from 'astra-ai';

let attitude = {
    bot_name: "astra",
    purpose: "personal",
    tasks: "Hobbies, interests or just chat for fun"
};

let astra = new AstraAI(attitude);

astra.chat("summarize- artificial intelligence is a technology widely growing in the 20s centuary. it is highly used for mimickering human decision making skills & more. Ai is widely used in healthcare and more such industries.",attitude)
.then((response) => {
    console.log(response);
})
.catch((error) => {
    console.error("Error:", error);
});

```
Follow The Steps And See Astra.AI in Action!

## FeedBack & Contact
I always await your feedback on the improvement of visionary and innovative - **Astra.AI**. To directly contact me, mail me at either 
codeclutch.adamyarao@gmail.com or anuradhamaheshwari48@gmail.com. I'm also available for full stack jobs or freelance works. 
I make 3D, responsive websites at least prices.

_Once again, Thank You For Choosing Astra. It have only one vision - getting developers out of struggle to improve productivity though Artificial Intelligence._


### **Adamya Khairwal**
##### _Developer of Astra.AI_